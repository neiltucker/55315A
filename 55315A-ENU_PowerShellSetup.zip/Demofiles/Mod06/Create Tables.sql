-- Create a database and change database context
USE [master]
GO

IF EXISTS (SELECT * FROM sys.sysdatabases WHERE[Name] = 'Demo6')
BEGIN
DROP DATABASE Demo6
END
GO
CREATE DATABASE Demo6
GO
USE Demo6
GO

-- Verify identity, then create database administrator user account
SELECT SUSER_NAME() as "Login", USER_NAME() as "User"
GO
USE Demo6
GO
CREATE LOGIN sqladmin1   
WITH PASSWORD = 'Password1',
DEFAULT_DATABASE = Demo6
GO  
CREATE USER dbadmin1 FOR LOGIN sqladmin1  
GO
ALTER ROLE db_owner  
ADD MEMBER dbadmin1
GO

-- Use database administrator account to create database resources
EXECUTE AS USER = 'dbadmin1'
GO
SELECT SUSER_NAME() as "Login", USER_NAME() as "User"
GO

-- Create schemas
CREATE SCHEMA Person
GO
CREATE SCHEMA Sales
GO

-- Create tables
CREATE TABLE Person.Customer
(CustomerID INT IDENTITY (1,1) NOT NULL
,Name VARCHAR (50) NOT NULL
,DateOfBirth DATETIME NULL
,Address VARCHAR (50) NOT NULL
CONSTRAINT PK_Customer PRIMARY KEY (CustomerID))
GO

CREATE TABLE Sales.[Order]
(OrderID INT IDENTITY (1,1) NOT NULL
,CustomerID INT NOT NULL
,OrderDate DATETIME NOT NULL
CONSTRAINT PK_OrderID PRIMARY KEY (OrderID)
CONSTRAINT FK_Order_Customer FOREIGN KEY (CustomerID)
REFERENCES Person.Customer (CustomerID))
GO

CREATE TABLE Person.CustomerDemographics
(CustomerID int NOT NULL PRIMARY KEY
,Age tinyint NOT NULL 
,NumberOfChildren varchar(8) NOT NULL
CONSTRAINT FK_CustomerDemographics_Customer FOREIGN KEY (CustomerID)
REFERENCES Person.Customer (CustomerID))
GO

CREATE TABLE Person.Employee
(EmployeeID int IDENTITY NOT NULL PRIMARY KEY
,SSN char (12) NOT NULL
,LastName varchar (50) NOT NULL
,Firstname varchar (50) NOT NULL)
GO

-- Add Customers to Person.Customer Table
INSERT INTO Person.Customer
VALUES ('ABC Limited', '1 January 2023', '1 ABC Blvd')
GO
INSERT INTO Person.Customer
VALUES ('XYZ Limited', '2 January 2023', '2 XYZ Lane')
GO
SELECT * FROM Person.Customer
GO

-- Add Sales to Sales.Order Table
INSERT INTO Sales.[Order]
VALUES(1,GETDATE())
GO
INSERT INTO Sales.[Order]
VALUES(1,GETDATE())
GO
INSERT INTO Sales.[Order]
VALUES(2,GETDATE())
GO
INSERT INTO Sales.[Order]
VALUES(2,GETDATE())
GO
SELECT * FROM Sales.[Order]
GO

-- Add CHECK constraint to Sales.Order
ALTER TABLE Sales.[Order] ADD CONSTRAINT DF_OrderDate
    CHECK (OrderDate = GETDATE())
GO

-- Test CHECK constraint
INSERT INTO Sales.[Order]
VALUES(2,GETDATE()-1)
GO
SELECT * FROM Sales.[Order]
GO

-- Add DEFAULT constraint to Person.CustomerDemographics
ALTER TABLE Person.CustomerDemographics
ADD CONSTRAINT DF_NumberChildren DEFAULT 'Unknown' FOR NumberOfChildren
GO

-- Test DEFAULT constraint
INSERT INTO Person.CustomerDemographics (CustomerID, Age, NumberOfChildren)
VALUES (2,23,2)
INSERT INTO Person.CustomerDemographics (CustomerID, Age)
VALUES (1,23)
SELECT * FROM Person.CustomerDemographics
GO

-- Add UNIQUE constraint to Person.Employee
ALTER TABLE Person.Employee
ADD CONSTRAINT AK_SSN UNIQUE (SSN)
GO

-- Test UNIQUE constraint. 
INSERT INTO Person.Employee
VALUES (123456789,'Bailey', 'John')
GO

INSERT INTO Person.Employee
VALUES (123456789,'Bailey', 'Jonathan')
GO

SELECT * FROM Person.Employee
GO

-- Revert to original permissions
SELECT SUSER_NAME() as "Login", USER_NAME() as "User"
GO
REVERT
GO
SELECT SUSER_NAME() as "Login", USER_NAME() as "User"
GO
