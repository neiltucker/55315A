-- Create a Stored Procedure

USE Demo6
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE[Name] = 'lsp_CustomerOrders')
BEGIN
DROP PROCEDURE lsp_CustomerOrders
END
GO

CREATE PROCEDURE lsp_CustomerOrders
WITH EXECUTE AS OWNER
AS
SELECT C.CustomerID, [Name], DateOfBirth, OrderID
FROM Person.Customer as C
JOIN Sales.[Order] as O
ON C.CustomerID = O.CustomerID
GO

-- Execute the Procedure
EXECUTE lsp_CustomerOrders 
GO

-- Query the data directly without permissions
-- Verify identity, then create database administrator user account
SELECT SUSER_NAME() as "Login", USER_NAME() as "User"
GO
CREATE LOGIN sqluser1   
WITH PASSWORD = 'Password1',
DEFAULT_DATABASE = Demo6
GO  
CREATE USER sqluser1 FOR LOGIN sqluser1  
GO
EXECUTE AS USER = 'sqluser1'
GO
SELECT SUSER_NAME() as "Login", USER_NAME() as "User"
GO
SELECT C.CustomerID, [Name], DateOfBirth, OrderID
FROM Person.Customer as C
JOIN Sales.[Order] as O
ON C.CustomerID = O.CustomerID
GO
REVERT
GO
SELECT SUSER_NAME() as "Login", USER_NAME() as "User"
GO

-- Query the data using the procedure
GRANT EXECUTE ON lsp_CustomerOrders TO sqluser1
GO
EXECUTE AS USER = 'sqluser1'
GO
SELECT SUSER_NAME() as "Login", USER_NAME() as "User"
GO
EXECUTE lsp_CustomerOrders
GO
REVERT
GO
