-- Step 2
-- DO NOT RUN THE WHOLE SCRIPT, RUN EACH STEP INDIVIDUALLY
-- Run blocked query.

USE AdventureWorks2019
GO
SELECT * FROM Person.Person

------------------ END OF STEP 2 ------------------

