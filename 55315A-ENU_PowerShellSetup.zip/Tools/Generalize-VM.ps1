﻿### Sysprep the system and shutdown the computer (Perform in Administrator Command Prompt)
# rmdir %C:\Windows\Panther
# C:\Windows\System32\sysprep.exe 
# stop-azvm -resourcegroupname "init210327rg" -name "55315-MIA-SQL" -Force
# ConvertTo-AzVMManagedDisk -ResourceGroupName "init210327rg"-VMName "55315-MIA-SQL"

### Login to Azure
Connect-AzAccount
$SubscriptionName = (Get-AzSubscription)[0].Name
$Subscription = Get-AzSubscription -SubscriptionName $SubscriptionName | Select-AzSubscription

### Variables
$ResourceGroupName = "55315rg"
$Location = (Get-AzResourceGroup -ResourceGroupName $ResourceGroupName).Location
$DiskName = "55315MIASQL_OsDisk_1_c6767ae4ac8b407a82767a377a309061"
$Disk = Get-AzDisk -ResourceGroupName $ResourceGroupName -DiskName $DiskName
$ImageName = "55315sysprep"

### Create the image
# Disable-AzVMDiskEncryption -ResourceGroupName $ResourceGroupName -VMName $VMName" -VolumeType "all"
$ImageConfig = New-AzImageConfig -Location $Location
$ImageConfig = Set-AzImageOsDisk -Image $ImageConfig -OsState Generalized -OsType Windows -ManagedDiskId $Disk.Id
$Image = New-AzImage -ImageName $ImageName -ResourceGroupName "AzureLabs" -Image $ImageConfig


