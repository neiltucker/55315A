﻿$VMName = "55315-MIA-SQL"
$ResourceGroupName = "init070236rg"
$AzSubscription = "Azure Subscription 1"
$newDisk = "55315newdisk"

# Script
# Provide your Azure admin credentials
Connect-AzAccount

#Provide the subscription Id of the subscription where snapshot is created
Select-AzSubscription -Subscription $AzSubscription

Get-AzDisk -ResourceGroupName $ResourceGroupName | Format-Table -Property Name

# Get the VM 
$vm = Get-AzVM -ResourceGroupName $ResourceGroupName -Name $VMName 

# (Optional) Stop/ deallocate the VM
Stop-AzVM -ResourceGroupName $ResourceGroupName -Name $vm.Name -Force

# Get the new disk that you want to swap in
$disk = Get-AzDisk -ResourceGroupName $ResourceGroupName -Name $newDisk

# Set the VM configuration to point to the new disk  
Set-AzVMOSDisk -VM $vm -ManagedDiskId $disk.Id -Name $disk.Name 

# Update the VM with the new OS disk
Update-AzVM -ResourceGroupName $ResourceGroupName -VM $vm 

# Start the VM
Start-AzVM -Name $vm.Name -ResourceGroupName $ResourceGroupName