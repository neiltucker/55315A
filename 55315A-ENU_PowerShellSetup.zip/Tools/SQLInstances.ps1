$TimeStamp = Get-Date -F "yyyymmddHHmmss"
Rename-Item D:\Temp\SQLInstances.sql D:\Temp\SQLInstances_$env:ComputerName.$TimeStamp.sql -ErrorAction SilentlyContinue
[System.Data.SQL.SQLDataSourceEnumerator]::Instance.GetDataSources() | ForEach {"INSERT INTO SQLInstances Values ('$($_.ServerName)', '$($_.InstanceName)', '$($_.IsClustered)', '$($_.Version)')" ` >> D:\Temp\SQLInstances.sql }
