$Key=(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24)
$DomainUser = "Contoso\Administrator"
$DomainPassword = Cat D:\Labfiles\password.txt | ConvertTo-SecureString -Key $Key
$DomainCredentials = New-Object �TypeName System.Management.Automation.PSCredential �ArgumentList $DomainUser, $DomainPassword
Add-Computer -DomainName Contoso.com -Credential $DomainCredentials -Verbose -PassThru
reg import D:\Labfiles\AutoLogonAdmin1.reg
reg import D:\Labfiles\ServerConfig.reg
Shutdown /r /t 10