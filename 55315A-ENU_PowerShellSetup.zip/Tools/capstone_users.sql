/* Create user accounts for users who will use views and stored procedures. 
   One user should have access to only views and the other to only procedures.
   Test their permissions to verify they have only the permissions they need. */

USE Capstone
GO
CREATE USER Victor WITHOUT LOGIN
GO
CREATE USER Sam WITHOUT LOGIN
GO
GRANT SELECT ON OBJECT::dbo.vw_CustomerLocation TO Victor
GRANT SELECT ON OBJECT::dbo.vw_CustomerZip TO Victor
GRANT SELECT ON OBJECT::dbo.vw_employees TO Victor
GRANT SELECT ON OBJECT::dbo.vw_hiredate TO Victor
GRANT SELECT ON OBJECT::dbo.vw_totalsales TO Victor
GO
GRANT EXECUTE ON OBJECT::dbo.lsp_customers TO Sam
GRANT EXECUTE ON OBJECT::dbo.lsp_employees TO Sam
GRANT EXECUTE ON OBJECT::dbo.lsp_sales TO Sam
GO
EXECUTE AS USER = 'Victor'
SELECT USER_NAME()
SELECT * FROM vw_CustomerLocation
EXECUTE lsp_customers
REVERT
SELECT USER_NAME()
GO
EXECUTE AS USER = 'Sam'
SELECT USER_NAME()
SELECT * FROM vw_CustomerLocation
EXECUTE lsp_customers
REVERT
SELECT USER_NAME()




