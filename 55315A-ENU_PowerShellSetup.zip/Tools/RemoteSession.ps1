$Session = New-PSSession -ComputerName NYC-DC1
Invoke-Command -Session $Session {Import-Module ActiveDirectory; Import-Module SQLPS}
Import-PSSession -Session $Session
$Session
# Remove-PSSession -Session $Session