USE [master]
GO
EXEC xp_instance_regwrite N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'LoginMode', REG_DWORD, 2
GO
ALTER LOGIN [sa] ENABLE
GO
ALTER LOGIN [sa] WITH PASSWORD=N'Password1'
GO
CREATE LOGIN [BUILTIN\Administrators] FROM WINDOWS WITH DEFAULT_DATABASE=[master]
GO
ALTER SERVER ROLE [sysadmin] ADD MEMBER [BUILTIN\Administrators]
GO
Declare @NEW_LOGIN_NAME varchar(30)
Set @NEW_LOGIN_NAME = @@ServerName + '\Adminz'
Declare @sqlstmt1 varchar(200)
Declare @sqlstmt2 varchar(200)
Set @sqlstmt1='CREATE LOGIN [' + @NEW_LOGIN_NAME + '] FROM WINDOWS WITH DEFAULT_DATABASE=[master]'
Set @sqlstmt2='ALTER SERVER ROLE [sysadmin] ADD MEMBER [' + @NEW_LOGIN_NAME + ']' 
Exec (@sqlstmt1)
Exec (@sqlstmt2)
GO
Declare @NEW_LOGIN_NAME varchar(30)
Set @NEW_LOGIN_NAME = @@ServerName + '\Student'
Declare @sqlstmt1 varchar(200)
Declare @sqlstmt2 varchar(200)
Set @sqlstmt1='CREATE LOGIN [' + @NEW_LOGIN_NAME + '] FROM WINDOWS WITH DEFAULT_DATABASE=[master]'
Set @sqlstmt2='ALTER SERVER ROLE [sysadmin] ADD MEMBER [' + @NEW_LOGIN_NAME + ']' 
Exec (@sqlstmt1)
Exec (@sqlstmt2)
GO
CREATE LOGIN [sqllogin1] WITH PASSWORD=N'Password1', DEFAULT_DATABASE=[master]
GO
ALTER SERVER ROLE [sysadmin] ADD MEMBER [sqllogin1]
GO
CREATE LOGIN [sqllogin2] WITH PASSWORD=N'Password1', DEFAULT_DATABASE=[master]
GO
ALTER SERVER ROLE [sysadmin] ADD MEMBER [sqllogin2]
GO
EXEC SP_CONFIGURE 'SHOW ADVANCED OPTIONS', 1
RECONFIGURE
GO
EXEC SP_CONFIGURE 'AD HOC DISTRIBUTED QUERIES', 1
RECONFIGURE
GO
