USE [master]
GO
/****** Object:  Database [Capstone]    Script Date: 10/16/2022 4:12:51 PM ******/
CREATE DATABASE [Capstone]
GO
ALTER DATABASE [Capstone] SET COMPATIBILITY_LEVEL = 140
GO
ALTER DATABASE [Capstone] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [Capstone] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [Capstone] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [Capstone] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [Capstone] SET ARITHABORT OFF 
GO
ALTER DATABASE [Capstone] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [Capstone] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [Capstone] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [Capstone] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [Capstone] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [Capstone] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [Capstone] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [Capstone] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [Capstone] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [Capstone] SET  DISABLE_BROKER 
GO
ALTER DATABASE [Capstone] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [Capstone] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [Capstone] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [Capstone] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [Capstone] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [Capstone] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [Capstone] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [Capstone] SET RECOVERY FULL 
GO
ALTER DATABASE [Capstone] SET  MULTI_USER 
GO
ALTER DATABASE [Capstone] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [Capstone] SET DB_CHAINING OFF 
GO
ALTER DATABASE [Capstone] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [Capstone] SET TARGET_RECOVERY_TIME = 0 SECONDS 
GO
ALTER DATABASE [Capstone] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [Capstone] SET QUERY_STORE = OFF
GO
USE [Capstone]
GO
/****** Object:  Table [dbo].[employees]    Script Date: 10/16/2022 4:12:53 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[employees](
	[EmployeeID] [nvarchar](50) NOT NULL,
	[LastName] [nvarchar](50) NOT NULL,
	[FirstName] [nvarchar](50) NOT NULL,
	[DateOfBirth] [date] NOT NULL,
	[HireDate] [date] NOT NULL,
	[Salary] [int] NOT NULL,
	[JobTitle] [nvarchar](50) NOT NULL,
	[DepartmentID] [tinyint] NOT NULL,
 CONSTRAINT [PK_employees] PRIMARY KEY CLUSTERED 
(
	[EmployeeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_employees]    Script Date: 10/16/2022 4:12:53 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[vw_employees]
AS
SELECT EmployeeID, LastName, FirstName, JobTitle 
FROM Employees
GO
/****** Object:  View [dbo].[vw_hiredate]    Script Date: 10/16/2022 4:12:53 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[vw_hiredate]
AS
SELECT LastName, FirstName, HireDate 
FROM Employees
GO
/****** Object:  Table [dbo].[sales]    Script Date: 10/16/2022 4:12:53 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[sales](
	[SalesID] [smallint] NOT NULL,
	[CustomerID] [nvarchar](50) NOT NULL,
	[SalesRepID] [nvarchar](50) NOT NULL,
	[Sales] [float] NOT NULL,
	[Surcharge] [float] NOT NULL,
	[DateOfSales] [date] NOT NULL,
 CONSTRAINT [PK_sales] PRIMARY KEY CLUSTERED 
(
	[SalesID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_totalsales]    Script Date: 10/16/2022 4:12:53 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[vw_totalsales]
WITH SCHEMABINDING
AS
SELECT CustomerID, sum(Sales + Surcharge) as TotalSales, COUNT_BIG(*) as COUNT
FROM dbo.Sales 
GROUP BY CustomerID
GO
SET ARITHABORT ON
SET CONCAT_NULL_YIELDS_NULL ON
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
SET NUMERIC_ROUNDABORT OFF
GO
/****** Object:  Index [ci_totalsales]    Script Date: 10/16/2022 4:12:53 PM ******/
CREATE UNIQUE CLUSTERED INDEX [ci_totalsales] ON [dbo].[vw_totalsales]
(
	[CustomerID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[customers]    Script Date: 10/16/2022 4:12:53 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[customers](
	[CustomerID] [nvarchar](50) NOT NULL,
	[FirstName] [nvarchar](50) NOT NULL,
	[LastName] [nvarchar](50) NOT NULL,
	[Phone] [nvarchar](50) NOT NULL,
	[Street] [nvarchar](50) NOT NULL,
	[City] [nvarchar](50) NOT NULL,
	[State] [nvarchar](50) NOT NULL,
	[Zip] [int] NOT NULL,
 CONSTRAINT [PK_customers] PRIMARY KEY CLUSTERED 
(
	[CustomerID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_CustomerLocation]    Script Date: 10/16/2022 4:12:53 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[vw_CustomerLocation]
AS
SELECT LastName, FirstName, CustomerID, State 
FROM Customers 
GO
/****** Object:  View [dbo].[vw_CustomerZip]    Script Date: 10/16/2022 4:12:53 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[vw_CustomerZip]
AS
SELECT Zip, CustomerID, FirstName, LastName 
FROM Customers 
GO
/****** Object:  Table [dbo].[department]    Script Date: 10/16/2022 4:12:53 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[department](
	[DepartmentID] [tinyint] NOT NULL,
	[DepartmentName] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_department] PRIMARY KEY CLUSTERED 
(
	[DepartmentID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NC_CustomerState]    Script Date: 10/16/2022 4:12:53 PM ******/
CREATE NONCLUSTERED INDEX [NC_CustomerState] ON [dbo].[customers]
(
	[State] ASC,
	[CustomerID] ASC,
	[FirstName] ASC,
	[LastName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NC_CustomerZip]    Script Date: 10/16/2022 4:12:53 PM ******/
CREATE NONCLUSTERED INDEX [NC_CustomerZip] ON [dbo].[customers]
(
	[Zip] ASC,
	[CustomerID] ASC,
	[FirstName] ASC,
	[LastName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NC_employees]    Script Date: 10/16/2022 4:12:53 PM ******/
CREATE NONCLUSTERED INDEX [NC_employees] ON [dbo].[employees]
(
	[EmployeeID] ASC,
	[LastName] ASC,
	[FirstName] ASC,
	[JobTitle] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NC_HireDate]    Script Date: 10/16/2022 4:12:53 PM ******/
CREATE NONCLUSTERED INDEX [NC_HireDate] ON [dbo].[employees]
(
	[HireDate] DESC,
	[LastName] ASC,
	[FirstName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE [dbo].[employees]  WITH CHECK ADD  CONSTRAINT [FK_employees_department] FOREIGN KEY([DepartmentID])
REFERENCES [dbo].[department] ([DepartmentID])
GO
ALTER TABLE [dbo].[employees] CHECK CONSTRAINT [FK_employees_department]
GO
ALTER TABLE [dbo].[sales]  WITH CHECK ADD  CONSTRAINT [FK_sales_customers] FOREIGN KEY([CustomerID])
REFERENCES [dbo].[customers] ([CustomerID])
GO
ALTER TABLE [dbo].[sales] CHECK CONSTRAINT [FK_sales_customers]
GO
ALTER TABLE [dbo].[sales]  WITH CHECK ADD  CONSTRAINT [FK_sales_employees] FOREIGN KEY([SalesRepID])
REFERENCES [dbo].[employees] ([EmployeeID])
ON UPDATE CASCADE
GO
ALTER TABLE [dbo].[sales] CHECK CONSTRAINT [FK_sales_employees]
GO
/****** Object:  StoredProcedure [dbo].[lsp_customers]    Script Date: 10/16/2022 4:12:53 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[lsp_customers]
AS
SELECT (c.LastName + ', ' + c.FirstName) as CustomerName, c.CustomerID, (e.LastName + ', ' + e.FirstName) as SalesRep
FROM Customers as c JOIN Sales as s
ON c.customerid = s.customerid
JOIN Employees as e
ON s.SalesRepID = e.employeeID
GO
/****** Object:  StoredProcedure [dbo].[lsp_employees]    Script Date: 10/16/2022 4:12:53 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[lsp_employees]
AS
Select EmployeeID, LastName, FirstName, JobTitle, d.DepartmentName
FROM Employees as e JOIN Department as d
ON e.departmentid = d.departmentid
GO
/****** Object:  StoredProcedure [dbo].[lsp_sales]    Script Date: 10/16/2022 4:12:53 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[lsp_sales]
AS
SELECT (e.LastName + ', ' + e.FirstName) as SalesRepName, sum(round(s.sales,2) + round(s.surcharge,2)) as TotalSales
FROM Employees as e JOIN Sales as s
ON e.employeeid = s.salesrepid
Group By e.lastname, e.firstname
GO
USE [master]
GO
ALTER DATABASE [Capstone] SET  READ_WRITE 
GO
