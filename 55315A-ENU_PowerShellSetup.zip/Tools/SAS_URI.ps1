﻿### Create SAS URI using Azure CLI
### $ProgressPreference = 'SilentlyContinue'; Invoke-WebRequest -Uri https://aka.ms/installazurecliwindows -OutFile .\AzureCLI.msi; Start-Process msiexec.exe -Wait -ArgumentList '/I AzureCLI.msi /quiet'; rm .\AzureCLI.msi

#Provide the subscription Id where the snapshot is created
$subscriptionId="33fd4cb5-220b-4888-a1a7-77f6af6f555a"

#Provide the name of your resource group where the snapshot is created
$resourceGroupName="azurelabs"

#Provide the snapshot name
$snapshotName="55315snap"

#Provide Shared Access Signature (SAS) expiry duration in seconds (such as 3600)
#Know more about SAS here: https://learn.microsoft.com/azure/storage/storage-dotnet-shared-access-signature-part-1
$sasExpiryDuration=3600

#Provide storage account name where you want to copy the underlying VHD file.
$storageAccountName="azurelabssa"

#Name of the storage container where the downloaded VHD will be stored.
$storageContainerName="55315container"

#Provide the access key for the storage account that you want to copy the VHD to.
$storageAccountKey="inAu5XVuoi+Zeiz3jpitEB0m27Ap021MNRsU0Usn+SSWehVyMFmX9KCdJwY8/q76uVk59L9bIR2m+ASthzlqOQ=="

#Give a name to the destination VHD file to which the VHD will be copied.
$destinationVHDFileName="55315OSDisk.vhd"

az login
az account set --subscription $subscriptionId

$sas=$(az snapshot grant-access --resource-group $resourceGroupName --name $snapshotName --duration-in-seconds $sasExpiryDuration --query [accessSas] -o tsv)

az storage blob copy start --destination-blob $destinationVHDFileName --destination-container $storageContainerName --account-name $storageAccountName --account-key $storageAccountKey --source-uri $sas

