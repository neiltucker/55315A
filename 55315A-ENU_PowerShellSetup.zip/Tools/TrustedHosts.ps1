# Configure VMs to trust each other without Kerberos credentials
# See the RemoteSession.ps1 file for details on creating a remote session
winrm s winrm/config/client '@{TrustedHosts="NYC-SRV1,NYC-SRV2,NYC-DC1"}'
