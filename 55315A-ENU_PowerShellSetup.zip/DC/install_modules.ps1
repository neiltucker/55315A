### Install Azure Modules
Set-PSRepository -Name PSGallery -InstallationPolicy Trusted 
If (Get-PackageProvider -Name NuGet) {Write-Output "NuGet PackageProvider already installed."} Else {Install-PackageProvider -Name "NuGet" -Force}
If (Get-Module -ListAvailable -Name PowerShellGet) {Write-Output "PowerShellGet module already installed"} Else {Find-Module PowerShellGet -IncludeDependencies | Install-Module -Force}
If (Get-Module -ListAvailable -Name AzureRM) {Write-Output "AzureRM module already installed" ; Import-Module AzureRM} Else {Find-Module AzureRM -IncludeDependencies | Install-Module ; Import-Module -Name AzureRM}
If (Get-Module -ListAvailable -Name SQLServer) {Write-Output "SQLServer module already installed" ; Import-Module SQLServer} Else {Install-Module -Name SQLServer -AllowClobber -Force ; Import-Module -Name SQLServer}
If (Get-Module -ListAvailable -Name AzureAD) {Write-Output "AzureAD module already installed" ; Import-Module AzureAD} Else {Install-Module AzureAD -Force ; Import-Module -Name AzureAD}


